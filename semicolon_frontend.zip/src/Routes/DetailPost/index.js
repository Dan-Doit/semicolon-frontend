import DetailPostContainer from "./DetailPostContainer";
export default DetailPostContainer;