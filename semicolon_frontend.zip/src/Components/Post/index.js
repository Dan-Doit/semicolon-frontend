import PostContainer from "./PostContainer";

export default PostContainer;